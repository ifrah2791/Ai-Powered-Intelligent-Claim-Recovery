function addClaim() {
  const data = {
    claimId: claimId.value,
    name: name.value,
    dob: dob.value,
    age: age.value,
    providerId: providerId.value,
    providerAddress: providerAddress.value,
    status: status.value,
    dependents: dependents.value,
    diagnosisCode: diagCode.value,
    diagnosisDescription: diagDesc.value
  };

  fetch("/api/claims", {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify(data)
  })
  .then(() => {
    alert("Added!");
    window.location.href = "dashboard.html";
  });
}