function login() {
  fetch("/api/login", {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({
      username: username.value,
      password: password.value
    })
  })
  .then(res => {
    if (!res.ok) throw new Error();
    window.location.href = "dashboard.html";
  })
  .catch(() => alert("Invalid Login"));
}
``