// ✅ Load all claims by default
window.onload = function () {
    loadAllClaims();
};

// ✅ Load all claims
function loadAllClaims() {
    fetch("/api/claims/all")
        .then(res => res.json())
        .then(data => renderTable(data));
}

// ✅ Search function
function search() {
    const id = document.getElementById("claimId").value.trim();

    if (!id) {
        loadAllClaims();
        return;
    }

    fetch(`/api/claims/${id}`)
        .then(res => {
            if (!res.ok) throw new Error();
            return res.json();
        })
        .then(data => renderTable([data]))
        .catch(() => {
            alert("Claim not found");
            loadAllClaims();
        });
}

// ✅ Clear function
function clearSearch() {
    document.getElementById("claimId").value = "";
    loadAllClaims();
}

// ✅ Render Table
function renderTable(data) {
    const tbody = document.querySelector("#claimTable tbody");
    tbody.innerHTML = "";

    data.forEach(c => {

        let statusColor = "green";

        if (c.claimStatus.includes("Denied")) {
            statusColor = "red";
        } else if (c.claimStatus.includes("Partial")) {
            statusColor = "orange";
        }

        const row = `
        <tr>
            <td>${c.claimId}</td>
            <td>${c.memberName}</td>
            <td>${c.dob}</td>
            <td>${c.age}</td>
            <td>${c.providerId}</td>
            <td>${c.billedAmt}</td>
            <td>${c.allowedAmt}</td>
            <td>${c.paidAmt}</td>
            <td style="color:${statusColor}; font-weight:bold;">
                ${c.claimStatus}
            </td>
            <td>${c.eligibilityStatus}</td>
            <td>${c.primaryPayer}</td>
            <td>${c.secondaryPayer}</td>
            <td>${c.submissionType}</td>
            <td>${c.duplicatePaid}</td>
            <td>${c.modifiers}</td>
            <td>${c.cobStatus}</td>
        </tr>
        `;

        tbody.innerHTML += row;
    });
}
