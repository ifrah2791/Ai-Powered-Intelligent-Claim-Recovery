const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");

const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(express.static("public"));

const DATA_FILE = "./data/claims.json";

// Read claims
function loadClaims() {
  return JSON.parse(fs.readFileSync(DATA_FILE));
}

// Save claims
function saveClaims(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

// Login API
app.post("/api/login", (req, res) => {
  const { username, password } = req.body;

  if (username === "admin" && password === "admin123") {
    return res.json({ success: true });
  }

  res.status(401).json({ message: "Invalid credentials" });
});

// Search claim
app.get("/api/claims/:id", (req, res) => {
  const claims = loadClaims();
  const claim = claims.find(c => c.claimId === req.params.id);

  if (!claim) return res.status(404).json({ message: "Not found" });

  res.json(claim);
});

// Add claim
app.post("/api/claims", (req, res) => {
  const claims = loadClaims();
  claims.push(req.body);
  saveClaims(claims);

  res.json({ message: "Claim added successfully" });
});

// Get all claims
app.get("/api/claims/all", (req, res) => {
    const claims = loadClaims();
    res.json(claims);
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));