const express = require("express");
const app = express();
const PORT = 4000;

app.use(express.json());

// ── Dummy data: 5 client records ──────────────────────────────────────────────
const clients = {
  C1001: {
    client_id: "C1001",
    name: "Alice Sharma",
    date_of_service: "2025-03-12",
    diagnosis_code: "J06.9",
    diagnosis_description: "Acute upper respiratory infection, unspecified",
    provider: "Dr. Mehta",
    status: "processed",
  },
  C1002: {
    client_id: "C1002",
    name: "Bob Jones",
    date_of_service: "2025-04-05",
    diagnosis_code: "E11.9",
    diagnosis_description: "Type 2 diabetes mellitus without complications",
    provider: "Dr. Krishnan",
    status: "processed",
  },
  C1003: {
    client_id: "C1003",
    name: "Carol Diaz",
    date_of_service: "2025-01-22",
    diagnosis_code: "M54.5",
    diagnosis_description: "Low back pain",
    provider: "Dr. Rao",
    status: "processed",
  },
  C1004: {
    client_id: "C1004",
    name: "David Lee",
    date_of_service: "2025-05-30",
    diagnosis_code: "I10",
    diagnosis_description: "Essential (primary) hypertension",
    provider: "Dr. Patel",
    status: "processed",
  },
  C1005: {
    client_id: "C1005",
    name: "Eva Patel",
    date_of_service: "2025-06-15",
    diagnosis_code: "F32.1",
    diagnosis_description: "Major depressive disorder, single episode, moderate",
    provider: "Dr. Suresh",
    status: "processed",
  },
 C1006: {
    client_id: "C1006",
    name: "Frank Wu",
    date_of_service: "2025-06-15",
    diagnosis_code: "F32.1",
    diagnosis_description: "Major depressive disorder, single episode, moderate",
    provider: "Dr. Suresh",
    status: "processed",
  },
 C1007: {
    client_id: "C1007",
    name: "Grace Chan",
    date_of_service: "2025-06-15",
    diagnosis_code: "F32.1",
    diagnosis_description: "Major depressive disorder, single episode, moderate",
    provider: "Dr. Suresh",
    status: "processed",
  },
};

// ── Routes ────────────────────────────────────────────────────────────────────

// Health check
app.get("/", (req, res) => {
  res.json({
    service: "Claims API",
    version: "1.0.0",
    status: "running",
    endpoints: [
      "GET  /api/v1/clients",
      "GET  /api/v1/clients/:client_id/claim",
    ],
  });
});

// GET all clients (summary list)
app.get("/api/v1/clients", (req, res) => {
  const list = Object.values(clients).map(({ client_id, name, date_of_service, diagnosis_code, status }) => ({
    client_id,
    name,
    date_of_service,
    diagnosis_code,
    status,
  }));
  res.json({ success: true, count: list.length, data: list });
});

// GET claim by client ID
app.get("/api/v1/clients/:client_id/claim", (req, res) => {
  const id = req.params.client_id.toUpperCase();
  const record = clients[id];

  if (!record) {
    return res.status(404).json({
      success: false,
      error: "CLIENT_NOT_FOUND",
      message: `No record found for client ID '${req.params.client_id}'`,
      hint: "Valid client IDs: C001, C002, C003, C004, C005",
    });
  }

  res.json({ success: true, data: record });
});

// 404 fallback
app.use((req, res) => {
  res.status(404).json({ success: false, error: "ROUTE_NOT_FOUND", message: `${req.method} ${req.path} is not a valid endpoint` });
});

// ── Start ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n✅  Claims API running at http://localhost:${PORT}`);
  console.log(`\nEndpoints:`);
  console.log(`  GET  http://localhost:${PORT}/`);
  console.log(`  GET  http://localhost:${PORT}/api/v1/clients`);
  console.log(`  GET  http://localhost:${PORT}/api/v1/clients/:client_id/claim`);
  console.log(`\nExample:`);
  console.log(`  curl http://localhost:${PORT}/api/v1/clients/C001/claim\n`);
});
